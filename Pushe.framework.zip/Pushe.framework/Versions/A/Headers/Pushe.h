//
//  Pushe.h
//  Pushe
//
//  Created by Saeid Scafee on 11/8/18.
//  Copyright © 2018 Saeid Scafee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Pushe : NSObject

@end
